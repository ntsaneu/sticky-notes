# 📝 Sticky Notes Application

A simple Django web application for creating, viewing, updating, and deleting sticky notes.

---

## 🚀 Features

- ✅ Create new notes with a title and content
- ✅ View a list of all notes (newest first)
- ✅ View the full content of a single note
- ✅ Edit an existing note
- ✅ Delete a note with confirmation
- ✅ Clean, responsive CSS styling
- ✅ Django admin interface for easy data management

---

## 🛠️ Technologies Used

- **Python** 3.8+
- **Django** 5.1
- **SQLite** (default database)
- **HTML5** & **CSS3**

---

## 🗂️ Project Structure

```text
sticky_notes/
├── diagrams/               # UML diagrams
├── notes/                  # Main application
│   ├── static/             # CSS files
│   ├── templates/          # HTML templates
│   ├── tests.py            # Unit tests
│   ├── models.py
│   ├── views.py
│   ├── forms.py
│   └── urls.py
├── sticky_notes/           # Project settings
├── README.md
├── requirements.txt
├── research_answers.md
├── sticky_github.txt
└── manage.py
