# Sticky Notes Application

A simple Django web application for creating, viewing, updating, and deleting sticky notes.

---

## 📌 Features

- ✅ Create new notes with a title and content
- ✅ View a list of all notes (ordered by creation date, newest first)
- ✅ View the full content of a single note
- ✅ Edit an existing note
- ✅ Delete a note with confirmation
- ✅ Clean, responsive CSS styling
- ✅ Django admin interface for easy data management

---

## 🛠️ Technologies Used

- **Python** 3.8+
- **Django** 4.2+
- **SQLite** (default database)
- **HTML5** & **CSS3**

---

## 📂 Project Structure


## 🚀 Step‑by‑Step Setup (with venv)

Follow these steps to get the app running on your local machine.

### 1️⃣ Create and activate a virtual environment

Open a terminal in the project root (`sticky_notes/`) and run:

```
- python -m venv venv
- pip install django (install django)
- python3 manage.py makemigration (Run database migrations)
- python3 manage.py migrate (Run database migrations)
- python manage.py runserver (Start the development server)
- pip freeze > requirements.txt (Save your dependencies )
