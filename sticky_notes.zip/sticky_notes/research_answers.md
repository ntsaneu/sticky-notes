# Research Answers

## 1. HTTP State Management (Session & Authentication)

HTTP is stateless, meaning each request is independent. To maintain state, web applications use **sessions** and **cookies**. A session stores user‑specific data on the server, and a session ID is sent to the client as a cookie. On each subsequent request, the browser sends the cookie, allowing the server to retrieve the session data.  
For **authentication**, after a user logs in, the server creates a session record and sets a secure, HTTP‑only cookie containing the session ID. The server validates this ID on each request to identify the user. Django’s built‑in session middleware handles this automatically, storing sessions in the database (or cache) and setting a `sessionid` cookie.  
Additionally, Django provides authentication views and decorators (`@login_required`) that check if a user is authenticated by inspecting the session. This approach ensures that state persists securely, and because the session data lives on the server, it cannot be tampered with by the client. To further enhance security, HTTPS should be enforced, and session cookies can be marked as `Secure` and `HttpOnly`.

## 2. Migrations to a Server‑based Relational Database (e.g., MariaDB)

To use MariaDB (a MySQL drop‑in), first install the appropriate database driver, e.g., `mysqlclient` or `PyMySQL`. Then, in `settings.py`, configure the `DATABASES` dictionary:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'sticky_notes_db',
        'USER': 'db_user',
        'PASSWORD': 'secure_password',
        'HOST': 'localhost',   # or your server IP
        'PORT': '3306',
    }
}