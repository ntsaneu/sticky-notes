from django.test import TestCase
from django.urls import reverse
from notes.models import Note
from notes.forms import NoteForm


class NoteModelTest(TestCase):
    """Tests for the Note model."""

    def setUp(self):
        self.note = Note.objects.create(
            title="Test Note",
            content="This is a test note."
        )

    def test_note_has_title(self):
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, "Test Note")

    def test_note_has_content(self):
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, "This is a test note.")

    def test_note_str(self):
        self.assertEqual(str(self.note), "Test Note")


class NoteViewTest(TestCase):
    """Tests for the Note views (CRUD)."""

    def setUp(self):
        self.note = Note.objects.create(
            title="Test Note",
            content="This is a test note."
        )

    def test_note_list_view(self):
        response = self.client.get(reverse('notes:note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Note")

    def test_note_detail_view(self):
        response = self.client.get(
            reverse('notes:note_detail', args=[self.note.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Note")
        self.assertContains(response, "This is a test note.")

    def test_note_create_view(self):
        response = self.client.post(reverse('notes:note_create'), {
            'title': 'New Note',
            'content': 'New content'
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Note.objects.count(), 2)
        new_note = Note.objects.last()
        self.assertEqual(new_note.title, 'New Note')

    def test_note_update_view(self):
        response = self.client.post(
            reverse('notes:note_update', args=[self.note.id]),
            {'title': 'Updated Note', 'content': 'Updated content'}
        )
        self.assertEqual(response.status_code, 302)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Note')
        self.assertEqual(self.note.content, 'Updated content')

    def test_note_delete_view(self):
        response = self.client.post(
            reverse('notes:note_delete', args=[self.note.id])
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Note.objects.count(), 0)


class NoteFormTest(TestCase):
    """Tests for the NoteForm."""

    def test_valid_form(self):
        form = NoteForm(data={'title': 'Test', 'content': 'Content'})
        self.assertTrue(form.is_valid())

    def test_invalid_form(self):
        form = NoteForm(data={'title': '', 'content': ''})
        self.assertFalse(form.is_valid())