"""
Model definitions for the sticky notes application.
"""

from django.db import models


class Note(models.Model):
    """
    Model representing a sticky note.

    Attributes:
        title (CharField): The title of the note (max 200 characters).
        content (TextField): The main content of the note.
        created_at (DateTimeField): Timestamp when the note was created.
    """

    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        """
        String representation of the note.

        Returns:
            str: The note's title.
        """
        return self.title